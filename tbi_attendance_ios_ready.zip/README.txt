# iOS Ready Flutter Project

This project supports both Android & iOS WebView.

If the `ios/` folder is missing, run:

flutter create .

Then upload to Codemagic to build your FREE iOS IPA.

